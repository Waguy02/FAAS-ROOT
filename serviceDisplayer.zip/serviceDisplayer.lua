module("luci.controller.serviceDisplayer", package.seeall)

function index()
	entry({"admin", "services", "test"}, template("serviceDisplayer/index"), "ServiceDisplayer",60)
end